#version 150
#define VSH
#define RENDERTYPE_TEXT

#moj_import <fog.glsl>

// These are inputs and outputs to the shader
// If you are merging with a shader, put any inputs and outputs that they have, but are not here already, in the list below
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat3 IViewRotMat;
uniform float GameTime;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec4 baseColor;
out vec4 lightColor;

#moj_import <spheya_packs_impl.glsl>

void main() {
    vec3 pos = Position;

    baseColor = Color;
    lightColor = texelFetch(Sampler2, UV2 / 16, 0);

    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
    vertexColor = baseColor * lightColor;
    texCoord0 = UV0;

    if(applySpheyaPacks()) return;

    // When merging with another shader, you should put the code in their main() function below here
	vec2 pixel = vec2(ProjMat[0][0], ProjMat[1][1]) / 2.0;
	int guiScale = int(round(pixel.x / (1 / ScreenSize.x)));
	vec2 guiSize = ScreenSize / guiScale;

	int offset = int(round(guiSize.y - Position.y));
	
	// Detect if GUI text.
	if (Position.z != 0.0 && Position.z != -90.0) {
		// Detect ascent of pixel.
		if (offset > -110000 && offset <= -100000) {
			pos.y -= 105000;
		}
	} 

	gl_Position = ProjMat * ModelViewMat * vec4(pos, 1);
}
